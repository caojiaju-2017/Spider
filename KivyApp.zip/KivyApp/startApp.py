#!/usr/local/bin/python
#-*- coding:utf-8 -*-

from MainApp import *

if __name__ == '__main__':
    MainApp().run()