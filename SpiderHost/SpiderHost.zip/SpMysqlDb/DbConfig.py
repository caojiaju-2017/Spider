#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pymongo

class DbConfig(object):
    # ip = "115.159.224.104"
    ip = "localhost"
    port = 3306
    dbName = "spiderconfig"
    userName = "root"
    password = "caojj123"

    # ip = "localhost"
    # port = 3306
    # dbName = "spiderconfig"
    # userName = "root"
    # password = "123456"