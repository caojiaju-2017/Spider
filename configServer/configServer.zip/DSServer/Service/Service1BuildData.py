#!/usr/bin/env python
# -*- coding: utf-8 -*-

# 公共处理函数
from publicFunction import *
import shutil

class Service1BuildData(object):
    @staticmethod
    def buildData():
        datas = {}

        return datas