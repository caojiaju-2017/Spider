#!/usr/bin/env python
# -*- coding: utf-8 -*-


class QueryStruct(object):
    def __init__(self):
        self.userName = None
        self.pageIndex = -1
        self.pageSize = 0
        self.srvCode = None
        self.fliterStr = None
